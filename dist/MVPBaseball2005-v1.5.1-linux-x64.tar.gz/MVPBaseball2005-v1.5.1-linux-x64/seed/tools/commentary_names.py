"""Which recording the commentators use for each player of a modern roster (playerattrib_audioid), so that every name
the game says is the right player's.

The play-by-play men recorded surnames (SPCH_PBP/PNAMEHDR.BIG: NNNNa-d.hdr, four inflections) and the stadium
announcer full names (SPCH_PA/PNAMEHDR.BIG: NNNN.hdr), both keyed by the audio id. EA's rookie generator names its
made-up players by surname through ROOKIE.BIG/audioid.csv.

  * a player who was in the 2005 game under the same full name keeps that player's id: both announcers are right;
  * a player whose surname (the whole surname: "De La Cruz" is not "Cruz") was recorded gets a NEW id (one the disc
    leaves unused, inside its range), whose play-by-play entries are copies of that surname's: the play-by-play says the surname, and the stadium
    announcer, who has no entry for the new id, skips the name - he never says another player's first name (the old
    way shared the 2005 player's id, so 2026's Teoscar Hernandez was announced as "Carlos Hernandez");
  * anyone else gets no id: the game skips the name, as it does for its own rookies without a recording.

The play-by-play index is written whole (pbp_archive), its directory in name order like the disc's.
"""
import re, unicodedata
from bigfile import read_big
import refpack, mvpdb


def norm(x):
    x = unicodedata.normalize('NFKD', x).encode('ascii', 'ignore').decode()
    x = x.lower().replace(' jr.', '').replace(' jr', '').replace(' sr.', '').replace(' ii', '').replace(' iii', '')
    return re.sub(r'[^a-z ]', '', x.replace('-', ' ')).strip()


def rookie_surnames(rookie_big):
    """surname -> audio id (ROOKIE.BIG/audioid.csv)"""
    out = {}
    for n, o, s in read_big(rookie_big):
        if n.lower() != 'audioid.csv': continue
        c = rookie_big[o:o + s]
        if c[:2] != b'Pl': c = refpack.decompress(c)
        for ln in c.decode('latin1').splitlines()[1:]:
            i, _, nm = ln.partition(',')
            if i.strip().isdigit(): out.setdefault(norm(nm.strip().strip('"')), int(i))
    return out


def pbp_members(pbp_hdr_big):
    """audio id -> {member name: bytes} of the play-by-play index"""
    out = {}
    for n, o, s in read_big(pbp_hdr_big):
        if len(n) >= 8 and n[:4].isdigit() and n.endswith('.hdr'): out.setdefault(int(n[:4]), {})[n] = pbp_hdr_big[o:o + s]
    return out


class Assigner:
    def __init__(self, disc_players, rookie_big, pbp_hdr_big, pa_hdr_big, other_ids=()):
        """disc_players: (first, last, audio id) of the disc's own players; other_ids: ids used elsewhere (managers)"""
        self.full = {}; self.sur = {}
        for f, l, a in disc_players:
            if a: self.full.setdefault((norm(f), norm(l)), a); self.sur.setdefault(norm(l), a)
        for s, a in rookie_surnames(rookie_big).items(): self.sur.setdefault(s, a)
        self.pbp = pbp_members(pbp_hdr_big); self.pbp_big = pbp_hdr_big
        used = set(self.pbp) | set(pbp_members(pa_hdr_big)) | {a for _, _, a in disc_players} | set(self.sur.values()) | set(other_ids)
        for n, o, s in read_big(pa_hdr_big):
            if n[:4].isdigit(): used.add(int(n[:4]))
        self.free = [i for i in range(100, max(self.pbp)) if i not in used]   # unused ids inside the disc's range
        self.copies = {}                          # surname's id -> new id
        self.stats = {'full name': 0, 'surname': 0, 'none': 0}

    def __call__(self, first, last):
        """the audio id for a player who is not one of the disc's own"""
        a = self.full.get((norm(first), norm(last)))
        if a and a in self.pbp: self.stats['full name'] += 1; return a
        a = self.sur.get(norm(last))
        if not a or a not in self.pbp: self.stats['none'] += 1; return 0
        if a not in self.copies:
            if len(self.copies) >= len(self.free): self.stats['none'] += 1; return 0
            self.copies[a] = self.free[len(self.copies)]
        self.stats['surname'] += 1
        return self.copies[a]

    def surname_only(self, last):
        """for managers: the surname id, copied likewise"""
        return self('', last) if norm(last) else 0

    def pbp_archive(self):
        """the play-by-play index (SPCH_PBP/PNAMEHDR.BIG) with the copies, in name order"""
        files = {n: self.pbp_big[o:o + s] for n, o, s in read_big(self.pbp_big)}
        files.update(self.new_members())
        return mvpdb.write_big(sorted(files.items()))

    def new_members(self):
        """member name -> bytes for the play-by-play index (SPCH_PBP/PNAMEHDR.BIG)"""
        out = {}
        for src, dst in self.copies.items():
            for n, b in self.pbp[src].items(): out['%04d%s' % (dst, n[4:])] = b
        return out
