#!/usr/bin/env python3
"""Redoes the announcer ids of a built commentary overlay (mods/commentary-2026, an era pack's commentary/) with
tools/commentary_names.py, so no player is called by another player's name.

    python3 tools/fix_commentary.py DISC COMMENTARY_DIR

DISC: a folder with the disc's DATA/DATABASE/DATABASE.BIG, DATA/DATABASE/ROOKIE.BIG,
DATA/AUDIO/SPCH_PBP/PNAMEHDR.BIG and DATA/AUDIO/SPCH_PA/PNAMEHDR.BIG (from the ISO, or the game's dump_disc/ with dump_disc.txt).
The disc's own players (same full name, same id as on the disc) keep their ids; everyone else is named again.
"""
import os, sys, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mvpdb
from commentary_names import Assigner, norm


def main():
    disc, comm = sys.argv[1], sys.argv[2]
    rd = lambda p: open(os.path.join(disc, p), 'rb').read()
    T0 = mvpdb.read_database(os.path.join(disc, 'DATA/DATABASE/DATABASE.BIG'))[0]
    dbp = os.path.join(comm, 'DATA/DATABASE/DATABASE.BIG')
    T, order = mvpdb.read_database(dbp)
    A0, A = T0['attrib.dat'], T['attrib.dat']; ci = A.col('playerattrib_audioid')
    disc_players = [(v[0], v[1], int(v[ci])) for k, v in A0.rows]
    own = {(norm(f), norm(l), a) for f, l, a in disc_players if a}
    mi0 = T0['manager.dat'].col('manager_audioid')
    asg = Assigner(disc_players, rd('DATA/DATABASE/ROOKIE.BIG'), rd('DATA/AUDIO/SPCH_PBP/PNAMEHDR.BIG'), rd('DATA/AUDIO/SPCH_PA/PNAMEHDR.BIG'),
                   [int(v[mi0]) for k, v in T0['manager.dat'].rows])
    kept = changed = 0
    for k, v in A.rows:
        a = int(v[ci])
        if a and (norm(v[0]), norm(v[1]), a) in own: kept += 1; continue
        n = asg(v[0], v[1])
        if n != a: changed += 1
        v[ci] = str(n)
    M0, M = T0['manager.dat'], T['manager.dat']; mi = M.col('manager_audioid')
    mown = {(norm(v[0]), norm(v[1]), int(v[mi])) for k, v in M0.rows if int(v[mi])}
    for k, v in M.rows:
        a = int(v[mi])
        if a and (norm(v[0]), norm(v[1]), a) in mown: continue
        v[mi] = str(asg.surname_only(v[1]))
    mvpdb.write_database(dbp, T, order)
    # the play-by-play index with the copies
    pd = os.path.join(comm, 'DATA/AUDIO/SPCH_PBP/PNAMEHDR.BIG')
    if os.path.isdir(pd): shutil.rmtree(pd)
    os.makedirs(os.path.dirname(pd), exist_ok=True)
    open(pd, 'wb').write(asg.pbp_archive())
    # the stadium announcer's index is the disc's again: nothing of it has to be hidden any more
    pa = os.path.join(comm, 'DATA/AUDIO/SPCH_PA/PNAMEHDR.BIG')
    if os.path.isfile(pa): os.remove(pa)
    print('%d players keep their own recordings, %d renamed; new players: %s; %d surname recordings copied' %
          (kept, changed, asg.stats, len(asg.copies)))


if __name__ == '__main__':
    main()
