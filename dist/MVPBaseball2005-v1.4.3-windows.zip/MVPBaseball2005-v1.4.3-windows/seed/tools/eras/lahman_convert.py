"""A season of the Lahman Baseball Database -> the roster builder's input files, so tools/build_rosters.py makes a
league as it was after that season (an era's first season is the next one).

    python3 tools/eras/lahman_convert.py LAHMAN_DIR SEASON OUT_DIR [--iso your.iso] [--modern game/rosters]

LAHMAN_DIR: the database's CSV files (People.csv, Batting.csv, Pitching.csv, Fielding.csv, Teams.csv; the
"core" folder of the download from sabr.org, CC BY-SA 3.0). OUT_DIR gets mvp_statsapi_<SEASON>.txt,
mvp_splits_<SEASON>.txt, mvp_savant_<SEASON>.txt and mvp_teams_<SEASON>.txt in the format tools/fetch_mlb_data.py
writes; then:

    python3 tools/build_rosters.py ISO OUT_DIR mods/pack-1977 1977

What goes in:
  - the big-league clubs of SEASON, each in the game's slot of its franchise (the Expos in the Nationals' slot,
    the Senators of 1960 in the Twins', the Brooklyn Dodgers in the Dodgers' ...). Slots whose franchise did not
    exist yet are filled like an expansion club, from the players left over;
  - every player who played in the majors in SEASON or the season before, with those seasons' lines (the builder
    rates him from them) and his career totals;
  - the farm systems: the players who reached the majors in the next five seasons, as they were then - prospects,
    rated from what they did in their first big-league years, discounted for age; the rest of the minor-league
    rosters are made-up players (names from the game's own rookie list) with lines for their level;
Lahman has no splits by pitcher hand, no batted-ball data and no Statcast: the builder falls back to the
overall lines, and running speed comes from stolen bases and triples.
"""
import sys, os, csv, collections, random, zlib, math

LAHMAN, SEASON, OUT = sys.argv[1], int(sys.argv[2]), sys.argv[3]
MODERN = sys.argv[sys.argv.index('--modern') + 1] if '--modern' in sys.argv else 'game/rosters'
os.makedirs(OUT, exist_ok=True)

# franchise (Lahman franchID) -> the game's slot, by the MLB club id the roster builder uses for it
FRANCH_ORG = {'ANA': 108, 'OAK': 133, 'SEA': 136, 'TEX': 140, 'CHW': 145, 'CLE': 114, 'DET': 116, 'KCR': 118, 'MIN': 142,
              'BAL': 110, 'BOS': 111, 'NYY': 147, 'TBD': 139, 'TOR': 141, 'ARI': 109, 'COL': 115, 'LAD': 119, 'SDP': 135,
              'SFG': 137, 'CHC': 112, 'CIN': 113, 'HOU': 117, 'MIL': 158, 'PIT': 134, 'STL': 138, 'ATL': 144, 'FLA': 146,
              'WSN': 120, 'NYM': 121, 'PHI': 143}

TWO_WORD = {'Red Sox', 'White Sox', 'Blue Jays', 'Devil Rays', 'Red Stockings', 'White Stockings', 'Blue Stockings', 'Black Sox',
            'Red Legs'}
def rows(name):
    p = os.path.join(LAHMAN, name)
    if not os.path.exists(p): return []
    with open(p, newline='', encoding='utf-8-sig', errors='replace') as f: return list(csv.DictReader(f))
def num(v):
    try: return float(v)
    except (TypeError, ValueError): return 0.0
def pid_of(s): return zlib.crc32(s.encode()) & 0x3fffffff | 0x40000000      # stable integer ids, apart from real MLBAM ones

people = {r['playerID']: r for r in rows('People.csv')}
teams = [r for r in rows('Teams.csv') if r['yearID'].isdigit()]
bat, pit, fld = rows('Batting.csv'), rows('Pitching.csv'), rows('Fielding.csv')
ofsplit = rows('FieldingOFsplit.csv')
years = lambda rs, lo, hi: [r for r in rs if lo <= int(r['yearID']) <= hi]

team_franch = {(int(t['yearID']), t['teamID']): t['franchID'] for t in teams}
season_teams = [t for t in teams if int(t['yearID']) == SEASON and t['lgID'] in ('AL', 'NL')]
org_of_team = {}
for t in season_teams:
    org = FRANCH_ORG.get(t['franchID'])
    if org: org_of_team[t['teamID']] = org
missing = sorted(set(FRANCH_ORG.values()) - set(org_of_team.values()))
# franchises that start the next season (the era's first, e.g. Seattle and Toronto in 1977): their first roster,
# the players who were with them then (most came from the other clubs in the expansion draft)
next_teams = {}
for t in teams:
    if int(t['yearID']) == SEASON + 1 and FRANCH_ORG.get(t['franchID']) in missing: next_teams[t['teamID']] = t
missing = [o for o in missing if o not in {FRANCH_ORG[t['franchID']] for t in next_teams.values()}]

# ---------------------------------------------------------------- stat lines in the builder's layout
HF = 'g pa ab h d t hr rbi r bb ibb so hbp sb cs sh sf go ao'.split()
PF = 'g gs outs h r er hr bb ibb so hbp w l sv bs cg sho bf go ao pk d t sf sh hld'.split()
FF = 'g gs inn po a e ch dp cs sb pb'.split()
def hline(r):
    ab, bb, hbp, sh, sf = num(r['AB']), num(r['BB']), num(r.get('HBP')), num(r.get('SH')), num(r.get('SF'))
    d = dict(g=num(r['G']), pa=ab + bb + hbp + sh + sf, ab=ab, h=num(r['H']), d=num(r['2B']), t=num(r['3B']), hr=num(r['HR']),
             rbi=num(r['RBI']), r=num(r['R']), bb=bb, ibb=num(r.get('IBB')), so=num(r['SO']), hbp=hbp, sb=num(r['SB']),
             cs=num(r['CS']), sh=sh, sf=sf, go=0, ao=0)
    return d
def qline(r):
    outs = num(r['IPouts']); bfp = num(r.get('BFP'))
    if not bfp: bfp = outs + num(r['H']) + num(r['BB']) + num(r.get('HBP'))
    return dict(g=num(r['G']), gs=num(r['GS']), outs=outs, h=num(r['H']), r=num(r.get('R')), er=num(r['ER']), hr=num(r['HR']),
                bb=num(r['BB']), ibb=num(r.get('IBB')), so=num(r['SO']), hbp=num(r.get('HBP')), w=num(r['W']), l=num(r['L']),
                sv=num(r['SV']), bs=0, cg=num(r['CG']), sho=num(r['SHO']), bf=bfp, go=0, ao=0, pk=0, d=0, t=0,
                sf=num(r.get('SF')), sh=num(r.get('SH')), hld=0)
def fmt(keys, d): return ','.join(('%d' % d[k]) if float(d[k]).is_integer() else ('%.1f' % d[k]) for k in keys)

out_lines = []
P, R, Hs, Qs, Fs, CH, CP = [], [], [], [], [], [], []
def person(pl, pos, pid=None, num_=''):
    p = people[pl] if isinstance(pl, str) else pl
    pid = pid or pid_of(p['playerID'])
    h = int(num(p.get('height'))) or 73
    try: birth = '%04d-%02d-%02d' % (int(p['birthYear']), int(p['birthMonth'] or 6), int(p['birthDay'] or 15))
    except (ValueError, TypeError): birth = ''
    P.append('P|%d|%s|%s|%s %s|%s|%s|%s|%s|%d\' %d"|%d|%s|%s|%s' % (pid, p['nameFirst'], p['nameLast'], p['nameFirst'], p['nameLast'], num_,
             pos, (p.get('bats') or 'R')[:1], (p.get('throws') or 'R')[:1], h // 12, h % 12, int(num(p.get('weight'))) or 190,
             birth, (p.get('debut') or '')[:10], p.get('birthCountry') or 'USA'))
    return pid

# who played where: the last club of SEASON (by stint)
last_club = {}
for r in years(bat, SEASON, SEASON) + years(pit, SEASON, SEASON):
    k = r['playerID']; st = int(r.get('stint') or 1)
    if k not in last_club or st >= last_club[k][0]: last_club[k] = (st, r['teamID'])
pos_games = collections.defaultdict(collections.Counter)
for r in years(fld, SEASON - 1, SEASON):
    pos = r['POS']
    if pos == 'OF': continue                                   # split below (or fall back)
    pos_games[r['playerID']][pos] += num(r['G']) * (1.0 if int(r['yearID']) == SEASON else 0.5)
of_split = collections.defaultdict(collections.Counter)
for r in years(ofsplit, SEASON - 1, SEASON): of_split[r['playerID']][r['POS']] += num(r['G'])
for r in years(fld, SEASON - 1, SEASON):
    if r['POS'] == 'OF':
        k = r['playerID']
        if of_split[k]:
            for p_, g in of_split[k].items(): pos_games[k][p_] += g
        else: pos_games[k]['CF' if num(r['G']) > 100 else 'RF'] += num(r['G'])
def main_pos(k):
    c = pos_games.get(k)
    if not c: return 'DH'
    pos = c.most_common(1)[0][0]
    return 'P' if pos == 'P' else pos
pitched_mostly = {k for k, c in pos_games.items() if c and c.most_common(1)[0][0] == 'P'}

# ---------------------------------------------------------------- big leaguers
mlb = set(r['playerID'] for r in years(bat, SEASON - 1, SEASON) if num(r['AB']) > 0) | \
      set(r['playerID'] for r in years(pit, SEASON - 1, SEASON) if num(r['IPouts']) > 0)
mlb = {k for k in mlb if k in people}
ids = {}
for k in sorted(mlb): ids[k] = person(k, 'P' if k in pitched_mostly else main_pos(k))
def org_for(team_id, year):
    return FRANCH_ORG.get(team_franch.get((year, team_id)), 0)
for r in years(bat, SEASON - 1, SEASON):
    k = r['playerID']
    if k not in ids: continue
    y = int(r['yearID']); Hs.append('H|%d|%d|1|%d|%s' % (y, ids[k], org_for(r['teamID'], y), fmt(HF, hline(r))))
for r in years(pit, SEASON - 1, SEASON):
    k = r['playerID']
    if k not in ids: continue
    y = int(r['yearID']); Qs.append('Q|%d|%d|1|%d|%s' % (y, ids[k], org_for(r['teamID'], y), fmt(PF, qline(r))))
for r in years(fld, SEASON - 1, SEASON):
    k = r['playerID']
    if k not in ids or r['POS'] == 'OF': continue
    y = int(r['yearID'])
    inn = num(r.get('InnOuts')) / 3.0 if r.get('InnOuts') else num(r['G']) * 8.0
    d = dict(g=num(r['G']), gs=num(r.get('GS')), inn=inn, po=num(r['PO']), a=num(r['A']), e=num(r['E']),
             ch=num(r['PO']) + num(r['A']) + num(r['E']), dp=num(r['DP']), cs=num(r.get('CS')), sb=num(r.get('SB')), pb=num(r.get('PB')))
    Fs.append('F|%d|%d|1|%d|%s|%s' % (y, ids[k], org_for(r['teamID'], y), r['POS'], fmt(FF, d)))
# careers to SEASON
cb, cp = collections.defaultdict(lambda: collections.Counter()), collections.defaultdict(lambda: collections.Counter())
for r in years(bat, 1871, SEASON):
    if r['playerID'] in ids: cb[r['playerID']].update(hline(r))
for r in years(pit, 1871, SEASON):
    if r['playerID'] in ids: cp[r['playerID']].update(qline(r))
for k, c in cb.items(): CH.append('CH|%d|%s' % (ids[k], fmt(HF, {f: c[f] for f in HF})))
for k, c in cp.items(): CP.append('CP|%d|%s' % (ids[k], fmt(PF, {f: c[f] for f in PF})))

# rosters: the last club of SEASON; "active" = the 25 who played most there, the rest on the 40-man list
by_org = collections.defaultdict(list)
moved = {}
for r in years(bat, SEASON + 1, SEASON + 1) + years(pit, SEASON + 1, SEASON + 1):
    if r['teamID'] in next_teams and int(r.get('stint') or 1) == 1: moved[r['playerID']] = FRANCH_ORG[next_teams[r['teamID']]['franchID']]
for k, (st, tm) in last_club.items():
    if k in ids and k in moved: by_org[moved[k]].append(k)
    elif k in ids and tm in org_of_team: by_org[org_of_team[tm]].append(k)
playing = collections.Counter()
for r in years(bat, SEASON, SEASON): playing[r['playerID']] += num(r['AB']) + num(r['BB'])
for r in years(pit, SEASON, SEASON): playing[r['playerID']] += num(r.get('BFP')) or num(r['IPouts']) * 1.4
for org, ks in by_org.items():
    ks.sort(key=lambda k: -playing[k])
    for i, k in enumerate(ks):
        R.append('R|%d|1|%d|%s|%d||%s|A' % (org, org, 'active' if i < 26 else '40Man', ids[k], 'P' if k in pitched_mostly else main_pos(k)))

# ---------------------------------------------------------------- farm systems: real prospects, then made-up players
modern_teams = [ln.rstrip('\n').split('|') for ln in open(os.path.join(MODERN, 'mvp_teams_2026.txt'), encoding='utf-8')]
farm = collections.defaultdict(dict)                         # org -> sport -> team id
for p in modern_teams:
    sp, org = int(p[1]), int(p[2])
    if sp in (11, 12, 13, 14) and org in FRANCH_ORG.values():
        lvl = 13 if sp == 14 else sp
        farm[org].setdefault(lvl, int(p[0]))
debut_year = {k: int(p['debut'][:4]) for k, p in people.items() if (p.get('debut') or '')[:4].isdigit()}
first_club = {}
for r in sorted(bat + pit, key=lambda r: (int(r['yearID']), int(r.get('stint') or 1))):
    first_club.setdefault(r['playerID'], (int(r['yearID']), r['teamID']))
rnd = random.Random(SEASON)
prospects = [k for k, y in debut_year.items() if SEASON < y <= SEASON + 5 and k in people and k not in ids]
def age_at(k, y):
    try: return y - int(people[k]['birthYear'])
    except (ValueError, TypeError): return 24
prospects = [k for k in prospects if 18 <= age_at(k, SEASON + 1) <= 26]
# a prospect's line: his first three big-league seasons, shrunk toward replacement for the years still to come
fut_b = collections.defaultdict(list); fut_p = collections.defaultdict(list)
for r in bat:
    if r['playerID'] in prospects and int(r['yearID']) <= debut_year[r['playerID']] + 2: fut_b[r['playerID']].append(r)
for r in pit:
    if r['playerID'] in prospects and int(r['yearID']) <= debut_year[r['playerID']] + 2: fut_p[r['playerID']].append(r)
def level_for(k):
    gap = debut_year[k] - SEASON
    return 11 if gap <= 1 else 12 if gap <= 3 else 13
placed = collections.Counter(); unplaced = set()           # (farm clubs full: these go to the next draft class)
for k in sorted(prospects, key=lambda k: debut_year[k]):
    fy, ft = first_club.get(k, (0, ''))
    org = FRANCH_ORG.get(team_franch.get((fy, ft), ''), 0)
    if org not in farm or org in missing: org = rnd.choice([o for o in farm if o not in missing] or list(farm))
    lvl = level_for(k)
    if placed[(org, lvl)] >= 24: unplaced.add(k); continue
    is_p = sum(num(r['IPouts']) for r in fut_p[k]) > sum(num(r['AB']) for r in fut_b[k]) * 0.5
    pid = person(k, 'P' if is_p else (main_pos(k) if k in pos_games else rnd.choice(['C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF'])))
    team = farm[org][lvl]
    if is_p:
        tot = collections.Counter()
        for r in fut_p[k]: tot.update(qline(r))
        if tot['bf'] < 1: continue
        f = 0.75                                            # a season at the level, from the rates of his future
        d = {x: tot[x] * f * 450 / max(tot['bf'], 1) for x in PF}
        Qs.append('Q|%d|%d|%d|%d|%s' % (SEASON, pid, lvl, team, fmt(PF, d)))
    else:
        tot = collections.Counter()
        for r in fut_b[k]: tot.update(hline(r))
        if tot['pa'] < 1: continue
        d = {x: tot[x] * 450 / max(tot['pa'], 1) for x in HF}
        Hs.append('H|%d|%d|%d|%d|%s' % (SEASON, pid, lvl, team, fmt(HF, d)))
    R.append('R|%d|%d|%d|active|%d||%s|A' % (team, lvl, org, pid, 'P' if is_p else 'X'))
    placed[(org, lvl)] += 1

# draft classes: the players who reached the majors later, each in the class of the year he was about 21 (or the
# year before his debut, when that came first), with the line of his first three big-league years at A level
draft_ids = []
too_young = {k for k, y in debut_year.items() if SEASON < y <= SEASON + 5 and k in people and k not in ids and age_at(k, SEASON + 1) < 18}
later = [k for k, y in debut_year.items() if (SEASON + 5 < y <= SEASON + 40 or k in too_young or k in unplaced) and k in people and k not in ids]
fb2, fp2 = collections.defaultdict(list), collections.defaultdict(list)
later_set = set(later)
for r in bat:
    k = r['playerID']
    if k in later_set and int(r['yearID']) <= debut_year[k] + 2: fb2[k].append(r)
for r in pit:
    k = r['playerID']
    if k in later_set and int(r['yearID']) <= debut_year[k] + 2: fp2[k].append(r)
for k in sorted(later, key=lambda k: debut_year[k]):
    try: by = int(people[k]['birthYear'])
    except (ValueError, TypeError): continue
    dy = max(SEASON + 1, min(debut_year[k] - 1, by + 21))
    is_p = sum(num(r['IPouts']) for r in fp2[k]) > sum(num(r['AB']) for r in fb2[k]) * 0.5
    tot = collections.Counter()
    if is_p:
        for r in fp2[k]: tot.update(qline(r))
        if tot['bf'] < 30: continue
    else:
        for r in fb2[k]: tot.update(hline(r))
        if tot['pa'] < 30: continue
    pid = person(k, 'P' if is_p else (main_pos(k) if k in pos_games else 'SS'))
    if is_p: Qs.append('Q|%d|%d|13|0|%s' % (SEASON, pid, fmt(PF, {x: tot[x] * 0.7 * 450 / max(tot['bf'], 1) for x in PF})))
    else: Hs.append('H|%d|%d|13|0|%s' % (SEASON, pid, fmt(HF, {x: tot[x] * 450 / max(tot['pa'], 1) for x in HF})))
    draft_ids.append((pid, dy))
with open(os.path.join(OUT, 'era_draft.txt'), 'w') as f:
    for pid, dy in draft_ids: f.write('%d|%d\n' % (pid, dy))

# made-up players to fill the farm clubs: names from the game's rookie list, lines a level's spread of talent
NAMES = [('John', 'Smith')]
if '--iso' in sys.argv:                                       # the game's own list of names for made-up players
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    import isofile, refpack
    from bigfile import read_big
    _rk = isofile.read_file(sys.argv[sys.argv.index('--iso') + 1], 'DATA/DATABASE/ROOKIE.BIG')
    for n_, o_, s_ in read_big(_rk):
        if n_.lower() == 'names.csv':
            c_ = _rk[o_:o_ + s_]; c_ = refpack.decompress(c_) if c_[1:2] == b'\xfb' else c_
            NAMES = [tuple(l.split(',')[:2]) for l in c_.decode('latin1').split('\r\n')[1:] if l.count(',') >= 2]
fake_n = 0
def fake(org, lvl, is_p):
    global fake_n
    fake_n += 1
    first, last = rnd.choice(NAMES)
    age = rnd.randint(19, 25) if lvl == 13 else rnd.randint(20, 27) if lvl == 12 else rnd.randint(22, 30)
    by = SEASON + 1 - age
    pl = dict(playerID='fake%d_%d' % (SEASON, fake_n), nameFirst=first, nameLast=last, height=str(rnd.randint(70, 77)),
              weight=str(rnd.randint(175, 225)), bats=rnd.choice('RRRL L'.replace(' ', '')) , throws=rnd.choice('RRRL'),
              birthYear=str(by), birthMonth=str(rnd.randint(1, 12)), birthDay=str(rnd.randint(1, 28)), debut='', birthCountry='USA')
    pos = 'P' if is_p else rnd.choice(['C', 'C', '1B', '2B', '3B', 'SS', 'LF', 'CF', 'RF'])
    pid = person(pl, pos)
    team = farm[org][lvl]
    z = rnd.gauss(-0.6, 0.8)                                    # talent: farm-hands, mostly below big-league level
    if is_p:
        bf = rnd.randint(150, 600)
        k_ = max(0.08, 0.15 + 0.025 * z); bb_ = max(0.05, 0.10 - 0.012 * z); hr_ = max(0.01, 0.028 - 0.004 * z); h_ = max(0.18, 0.25 - 0.012 * z)
        d = dict.fromkeys(PF, 0); d.update(g=bf // 25, gs=bf // 26 if rnd.random() < 0.5 else 0, bf=bf, so=round(bf * k_), bb=round(bf * bb_),
                                         hr=round(bf * hr_), h=round(bf * h_), outs=round(bf * 0.70))
        d['er'] = round(d['h'] * 0.45 + d['hr'] * 0.6 + d['bb'] * 0.3); d['r'] = round(d['er'] * 1.08)
        Qs.append('Q|%d|%d|%d|%d|%s' % (SEASON, pid, lvl, team, fmt(PF, d)))
    else:
        pa = rnd.randint(150, 600)
        avg = max(0.18, 0.250 + 0.02 * z); bb_ = max(0.04, 0.08 + 0.01 * z); so_ = max(0.08, 0.18 - 0.02 * z); hr_ = max(0.003, 0.022 + 0.008 * z)
        ab = round(pa * (1 - bb_ - 0.01)); h = round(ab * avg)
        d = dict.fromkeys(HF, 0); d.update(g=pa // 4, pa=pa, ab=ab, h=h, d=round(h * 0.19), t=round(h * 0.02 * (1 + max(0, z))), hr=round(pa * hr_),
                                         bb=round(pa * bb_), so=round(pa * so_), sb=max(0, round(rnd.gauss(5, 6))), cs=rnd.randint(0, 5), r=round(pa * 0.11), rbi=round(pa * 0.10))
        Hs.append('H|%d|%d|%d|%d|%s' % (SEASON, pid, lvl, team, fmt(HF, d)))
    R.append('R|%d|%d|%d|active|%d||%s|A' % (team, lvl, org, pid, pos))
for org in farm:
    for lvl, need in ((11, 26), (12, 24), (13, 24)):
        if lvl not in farm[org]: continue
        have = placed[(org, lvl)]
        n_p = max(0, need // 2 - have // 2); n_h = max(0, need - have - n_p)
        for _ in range(n_p): fake(org, lvl, True)
        for _ in range(n_h): fake(org, lvl, False)
# clubs whose franchise did not exist yet: an expansion club of made-up players around the leftovers (the builder
# fills the big-league roster from the best players no club has)
for org in missing:
    for _ in range(14): fake(org, 11, True)
    for _ in range(14): fake(org, 11, False)

# ---------------------------------------------------------------- write
with open(os.path.join(OUT, 'mvp_statsapi_%d.txt' % SEASON), 'w', encoding='utf-8') as f:
    f.write('#PEOPLE id|first|last|full|number|pos|bats|throws|height|weight|birth|debut|country\n')
    f.write('\n'.join(P) + '\n#ROSTER team|sport|org|type|id|number|pos|status\n' + '\n'.join(R) + '\n')
    f.write('#HIT season|id|sport|team|' + ','.join(HF) + '\n' + '\n'.join(Hs) + '\n')
    f.write('#PIT season|id|sport|team|' + ','.join(PF) + '\n' + '\n'.join(Qs) + '\n')
    f.write('#FLD season|id|sport|team|pos|' + ','.join(FF) + '\n' + '\n'.join(Fs) + '\n' + '\n'.join(CH + CP) + '\n')
open(os.path.join(OUT, 'mvp_splits_%d.txt' % SEASON), 'w').write('')
open(os.path.join(OUT, 'mvp_savant_%d.txt' % SEASON), 'w').write('none\tid\n')
with open(os.path.join(OUT, 'mvp_teams_%d.txt' % SEASON), 'w', encoding='utf-8') as f:
    names = {FRANCH_ORG[t['franchID']]: t for t in season_teams + list(next_teams.values()) if t['franchID'] in FRANCH_ORG}
    for p in modern_teams:
        org = int(p[2]); sp = int(p[1])
        if sp == 1 and org in names:
            t = names[org]; nm = t['name']; city, _, nick = nm.rpartition(' ')
            w = nm.split()
            if len(w) > 2 and ' '.join(w[-2:]) in TWO_WORD: city, nick = ' '.join(w[:-2]), ' '.join(w[-2:])
            if ' of ' in nm: city, _, nick = nm.split(' of ')[0].rpartition(' ')        # "Los Angeles Angels of Anaheim
            p = [p[0], p[1], p[2], t.get('teamIDBR') or t['teamID'], city or nm, nick, nm, p[7], p[8], t.get('park', '')]
        f.write('|'.join(p) + '\n')
# managers: who managed the club first in the next season (the era's first), else last in SEASON
mg = {}
for r in sorted(rows('Managers.csv'), key=lambda r: (int(r['yearID']), int(r.get('inseason') or 1))):
    y = int(r['yearID'])
    if y not in (SEASON, SEASON + 1): continue
    org = FRANCH_ORG.get(team_franch.get((y, r['teamID']), ''))
    if not org or r['playerID'] not in people: continue
    if y == SEASON + 1 and (org, 'next') in mg: continue
    mg[(org, 'next' if y == SEASON + 1 else 'last')] = people[r['playerID']]
with open(os.path.join(OUT, 'era_managers.txt'), 'w', encoding='utf-8') as f:
    for org in sorted(set(o for o, _ in mg)):
        p_ = mg.get((org, 'next')) or mg.get((org, 'last'))
        f.write('%d|%s|%s\n' % (org, p_['nameFirst'], p_['nameLast']))
# the league's scoring that season (runs per club and game), for the balance of simulated games
_r = sum(num(t.get('R')) for t in season_teams); _g = sum(num(t.get('G')) for t in season_teams)
open(os.path.join(OUT, 'era_runs.txt'), 'w').write('%.3f\n' % (_r / _g if _g else 4.42))
open(os.path.join(OUT, 'era.txt'), 'w').write('season %d\nclubs %d\nexpansion slots %s\nprospects %d\nmade-up farmhands %d\ndraft-class players %d\n' %
                                             (SEASON, len(org_of_team), ' '.join(map(str, missing)) or '-', sum(placed.values()), fake_n, len(draft_ids)))
print(open(os.path.join(OUT, 'era.txt')).read())
